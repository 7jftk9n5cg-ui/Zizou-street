-- ZIZOU STREET security update for an EXISTING Supabase project.
-- Run this only if you already created the tables with an earlier setup script.
-- This does not recreate tables or delete existing products/orders.

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.admins
    where lower(email) = lower(auth.jwt() ->> 'email')
  )
$$;

alter table public.admins enable row level security;
revoke all on table public.admins from anon, authenticated;
revoke all on function public.is_admin() from public;
revoke all on function public.is_admin() from anon;
grant execute on function public.is_admin() to authenticated;

alter table public.products enable row level security;
alter table public.settings enable row level security;
alter table public.orders enable row level security;

grant select on public.products, public.settings to anon, authenticated;
grant insert, update, delete on public.products, public.settings to authenticated;
grant insert on public.orders to anon, authenticated;
grant select, update, delete on public.orders to authenticated;

drop policy if exists "public reads products" on public.products;
drop policy if exists "admin writes products" on public.products;
create policy "public reads products" on public.products
  for select to anon, authenticated using (true);
create policy "admin writes products" on public.products
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public reads settings" on public.settings;
drop policy if exists "admin writes settings" on public.settings;
create policy "public reads settings" on public.settings
  for select to anon, authenticated using (true);
create policy "admin writes settings" on public.settings
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "anyone places order" on public.orders;
drop policy if exists "admin reads orders" on public.orders;
drop policy if exists "admin updates orders" on public.orders;
drop policy if exists "admin deletes orders" on public.orders;
create policy "anyone places order" on public.orders
  for insert to anon, authenticated with check (
    status = 'New'
    and length(ref) between 3 and 40
    and length(customer_name) between 2 and 120
    and length(phone) between 8 and 20
    and length(wilaya) between 2 and 80
    and length(commune) between 2 and 120
    and length(address) between 5 and 400
    and (notes is null or length(notes) <= 1000)
    and case when jsonb_typeof(items) = 'array'
      then jsonb_array_length(items) between 1 and 50
      else false end
    and subtotal >= 0 and delivery_fee >= 0
    and total = subtotal + delivery_fee
  );
create policy "admin reads orders" on public.orders
  for select to authenticated using (public.is_admin());
create policy "admin updates orders" on public.orders
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin deletes orders" on public.orders
  for delete to authenticated using (public.is_admin());

insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

drop policy if exists "public reads images" on storage.objects;
drop policy if exists "admin uploads images" on storage.objects;
drop policy if exists "admin updates images" on storage.objects;
drop policy if exists "admin deletes images" on storage.objects;
create policy "public reads images" on storage.objects
  for select using (bucket_id = 'product-images');
create policy "admin uploads images" on storage.objects
  for insert to authenticated with check (bucket_id = 'product-images' and public.is_admin());
create policy "admin updates images" on storage.objects
  for update to authenticated using (bucket_id = 'product-images' and public.is_admin())
  with check (bucket_id = 'product-images' and public.is_admin());
create policy "admin deletes images" on storage.objects
  for delete to authenticated using (bucket_id = 'product-images' and public.is_admin());

-- Keep the service_role key secret. Only the anon/public key belongs in config.js.
