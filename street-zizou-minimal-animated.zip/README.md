# ZIZOU STREET — Installation Netlify + Supabase

## 1. Fichiers du projet

- `index.html` : boutique et tableau de bord administrateur.
- `config.js` : URL Supabase et clé publique `anon`.
- `supabase-setup.sql` : installation initiale d'une nouvelle base Supabase.
- `supabase-security-update.sql` : mise à jour de sécurité si les tables existent déjà.
- `netlify.toml` : en-têtes HTTP de sécurité.

## 2. Configurer Supabase

1. Ouvrez votre projet sur [supabase.com](https://supabase.com).
2. Si c'est une **nouvelle base**, ouvrez `SQL Editor`, collez tout le contenu de `supabase-setup.sql`, puis exécutez-le une seule fois.
3. Si vous avez **déjà exécuté l'ancien script** et que les tables `admins`, `products`, `settings` et `orders` existent, ne relancez pas `supabase-setup.sql` : exécutez plutôt `supabase-security-update.sql`. Cette mise à jour ne recrée pas les tables et ne supprime pas vos produits ou commandes.
4. Dans `Authentication > Users`, créez votre utilisateur administrateur ou conservez l'utilisateur que vous avez déjà créé. Utilisez une adresse e-mail à laquelle vous avez accès et un mot de passe fort.
5. Dans `Authentication > Settings`, désactivez l'inscription publique (`Allow new users to sign up`) si vous ne voulez pas que d'autres personnes créent un compte.
6. Dans `SQL Editor`, autorisez uniquement votre adresse e-mail dans la table `admins` en exécutant, avec votre véritable adresse :

   `insert into public.admins (email) values ('votre-email@example.com');`

   Si l'adresse existe déjà, utilisez plutôt :

   `insert into public.admins (email) values ('votre-email@example.com') on conflict (email) do nothing;`

   N'ajoutez aucune autre adresse si vous souhaitez être le seul administrateur.
7. Dans `Project Settings > API`, copiez le **Project URL** et la clé **anon/public**. Ne copiez jamais la clé `service_role`.

## 3. Connecter le site à Supabase

Ouvrez `config.js` et remplacez les deux valeurs d'exemple :

- `url` : votre Project URL.
- `key` : votre clé `anon/public`.

Ne mettez jamais la clé `service_role` dans `config.js`, dans Netlify ou dans un fichier public.

## 4. Publier sur Netlify

1. Décompressez l'archive ZIP.
2. Vérifiez que `index.html`, `config.js` et `netlify.toml` se trouvent ensemble à la racine du dossier.
3. Déposez le dossier du site sur [Netlify Drop](https://app.netlify.com/drop), ou déployez-le depuis votre compte Netlify.
4. Ouvrez l'adresse du site, puis cliquez sur `Administration`.
5. Connectez-vous avec l'adresse e-mail et le mot de passe de l'utilisateur ajouté à la table `admins`.

## 5. Utilisation de l'administration

Le tableau de bord permet de :

- Ajouter, modifier et supprimer des produits.
- Modifier les photos, les prix, les tailles, les couleurs et le stock.
- Gérer les catégories.
- Consulter les commandes et modifier leur statut.
- Définir les frais de livraison par wilaya.
- Modifier les coordonnées WhatsApp et Instagram ainsi que les textes de la boutique.

Les produits et paramètres sont enregistrés dans Supabase. Les photos sont stockées dans le bucket `product-images`. Les visiteurs peuvent consulter les produits et envoyer une commande, mais seuls les comptes autorisés dans `admins` peuvent consulter ou modifier les commandes et gérer le catalogue.

## 6. Coordonnées de la boutique conservées

- WhatsApp : `213540044167`
- Instagram : `@boutique.zizou28`

## 7. Vérifications importantes

Les vérifications locales du code ne remplacent pas un test sur votre propre projet Supabase. Après le déploiement, testez réellement :

1. La connexion avec votre compte administrateur.
2. La connexion avec un compte non administrateur : il ne doit pas accéder au tableau de bord.
3. L'ajout, la modification et la suppression d'un produit.
4. L'envoi, le remplacement et la suppression d'une photo.
5. La création d'une commande depuis la boutique.
6. L'accès aux commandes uniquement avec votre compte administrateur.

Si une étape échoue, copiez le message d'erreur exact avant de modifier les politiques SQL.

## 8. État des tests effectués sur cette archive

- Vérification de la syntaxe JavaScript de `index.html` : réussie.
- Vérification de la syntaxe JavaScript de `config.js` : réussie.
- Vérification statique de la grille mobile à deux colonnes : présente.
- Vérification du contrôle de rôle administrateur via `is_admin()` : présent dans le code.
- Vérification réelle de l'authentification, des politiques RLS et du stockage : à effectuer sur votre propre projet Supabase. Cette archive n'a pas été connectée à votre base réelle.
