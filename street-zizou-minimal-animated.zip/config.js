// Configuration publique Supabase pour ZIZOU STREET.
// La clé publishable est destinée au navigateur; la sécurité dépend aussi des politiques RLS.
window.ZZ_SB = {
  url: 'https://enuwuwynbobwzfiulori.supabase.co',
  key: 'sb_publishable_vI3Z5EzxcF9AaGPOKfxmng_XlEuiy0O'
};
